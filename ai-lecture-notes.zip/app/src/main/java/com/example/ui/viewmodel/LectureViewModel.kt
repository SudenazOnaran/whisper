package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.*
import com.example.data.repository.LectureRepository
import com.example.data.api.GeminiClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.util.Log

enum class AppScreen {
    SPLASH,
    HOME,
    UPLOAD_LECTURE,
    RECORD_LECTURE,
    PROCESSING,
    TRANSCRIPT,
    SUMMARY,
    FLASHCARDS,
    QUIZ,
    HISTORY,
    SETTINGS
}

class LectureViewModel(application: Application) : AndroidViewModel(application) {
    
    private val TAG = "LectureViewModel"
    private val database = AppDatabase.getDatabase(application)
    private val repository = LectureRepository(database.lectureDao())

    // State Navigation
    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf<AppScreen>()

    // Current operating or viewing lecture
    private val _selectedLectureId = MutableStateFlow<Long?>(null)
    val selectedLectureId: StateFlow<Long?> = _selectedLectureId.asStateFlow()

    // Loaded lecture details
    private val _currentLecture = MutableStateFlow<LectureEntity?>(null)
    val currentLecture: StateFlow<LectureEntity?> = _currentLecture.asStateFlow()

    private val _currentTranscript = MutableStateFlow<TranscriptEntity?>(null)
    val currentTranscript: StateFlow<TranscriptEntity?> = _currentTranscript.asStateFlow()

    private val _currentSummary = MutableStateFlow<SummaryEntity?>(null)
    val currentSummary: StateFlow<SummaryEntity?> = _currentSummary.asStateFlow()

    private val _currentQuizQuestions = MutableStateFlow<List<QuizQuestionEntity>>(emptyList())
    val currentQuizQuestions: StateFlow<List<QuizQuestionEntity>> = _currentQuizQuestions.asStateFlow()

    private val _currentFlashcards = MutableStateFlow<List<FlashcardEntity>>(emptyList())
    val currentFlashcards: StateFlow<List<FlashcardEntity>> = _currentFlashcards.asStateFlow()

    // All lectures history
    val allLectures: StateFlow<List<LectureEntity>> = repository.allLectures
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Session
    private val _isUserLoggedIn = MutableStateFlow(true)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _currentUserEmail = MutableStateFlow("student@university.edu")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    // Recording State
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0)
    val recordingDurationSeconds: StateFlow<Int> = _recordingDurationSeconds.asStateFlow()

    private val _recorderAmplitude = MutableStateFlow(listOf<Float>())
    val recorderAmplitude: StateFlow<List<Float>> = _recorderAmplitude.asStateFlow()

    // Settings Parameters
    val selectedLanguage = MutableStateFlow("auto") // "en", "tr", "auto"
    val selectedModel = MutableStateFlow("medium") // "small", "medium"
    val isDeveloperMode = MutableStateFlow(true)

    // Quiz Live tracking
    private val _currentQuestionIndex = MutableStateFlow(0)
    val currentQuestionIndex: StateFlow<Int> = _currentQuestionIndex.asStateFlow()

    private val _selectedAnswerIndex = MutableStateFlow<String?>(null) // "A", "B", "C", "D"
    val selectedAnswerIndex: StateFlow<String?> = _selectedAnswerIndex.asStateFlow()

    private val _quizCorrectCount = MutableStateFlow(0)
    val quizCorrectCount: StateFlow<Int> = _quizCorrectCount.asStateFlow()

    private val _isQuizCompleted = MutableStateFlow(false)
    val isQuizCompleted: StateFlow<Boolean> = _isQuizCompleted.asStateFlow()

    private var recordingJob: Job? = null
    private var processingJob: Job? = null

    init {
        // Run splash timeout sequence
        viewModelScope.launch {
            delay(2500)
            navigateTo(AppScreen.HOME)
        }
    }

    // Navigation logic
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            backStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backStack.isNotEmpty()) {
            val prev = backStack.removeAt(backStack.size - 1)
            _currentScreen.value = prev
            return true
        }
        return false
    }

    fun clearBackStackAndNavigate(screen: AppScreen) {
        backStack.clear()
        _currentScreen.value = screen
    }

    // Authentication mock
    fun login(email: String) {
        viewModelScope.launch {
            _currentUserEmail.value = if (email.trim().isEmpty()) "student@university.edu" else email.trim()
            _isUserLoggedIn.value = true
            clearBackStackAndNavigate(AppScreen.HOME)
        }
    }

    fun logout() {
        _isUserLoggedIn.value = true
        _currentUserEmail.value = "student@university.edu"
        clearBackStackAndNavigate(AppScreen.HOME)
    }

    // Select a lecture and pre-load all its components
    fun selectLecture(lectureId: Long) {
        _selectedLectureId.value = lectureId
        
        viewModelScope.launch {
            // Fetch lecture
            val lecture = repository.getLectureById(lectureId)
            _currentLecture.value = lecture
            
            if (lecture != null) {
                // Fetch transcript
                _currentTranscript.value = repository.getTranscriptForLecture(lectureId)
                // Fetch summary
                _currentSummary.value = repository.getSummaryForLecture(lectureId)
                // Fetch quiz questions
                _currentQuizQuestions.value = repository.getQuizForLecture(lectureId)
                
                // Collect flashcards reactively
                repository.getFlashcardsForLectureFlow(lectureId).collect { list ->
                    _currentFlashcards.value = list
                }
            }
        }
    }

    // Delete a lecture
    fun deleteLecture(lectureId: Long) {
        viewModelScope.launch {
            repository.deleteLecture(lectureId)
            if (_selectedLectureId.value == lectureId) {
                _selectedLectureId.value = null
                _currentLecture.value = null
                _currentTranscript.value = null
                _currentSummary.value = null
                _currentFlashcards.value = emptyList()
                _currentQuizQuestions.value = emptyList()
            }
        }
    }

    // Voice Recorder Simulator
    fun startRecording(title: String) {
        val finalTitle = title.trim().ifEmpty { "Lecture - " + System.currentTimeMillis() % 100000 }
        _isRecording.value = true
        _recordingDurationSeconds.value = 0
        _recorderAmplitude.value = emptyList()

        recordingJob = viewModelScope.launch {
            while (_isRecording.value) {
                delay(1000)
                _recordingDurationSeconds.value += 1
                
                // Add simulated audio amplitude peaks for beautiful live recording canvas waves
                val randomAmp = (0.2f + Math.random().toFloat() * 0.8f).coerceIn(0.1f, 1.0f)
                val currentList = _recorderAmplitude.value.takeLast(40).toMutableList()
                currentList.add(randomAmp)
                _recorderAmplitude.value = currentList
            }
        }
    }

    fun stopRecordingAndProcess(title: String) {
        _isRecording.value = false
        recordingJob?.cancel()

        val durationSec = _recordingDurationSeconds.value.toLong().coerceAtLeast(5)
        val finalTitle = title.trim().ifEmpty { "Recorded Lecture " + (System.currentTimeMillis() % 1000) }

        viewModelScope.launch {
            // Create database entry with status PROCESSING
            val id = repository.createLecture(
                title = finalTitle,
                durationSeconds = durationSec,
                language = selectedLanguage.value,
                modelSize = selectedModel.value,
                status = "RECORDING"
            )
            
            _selectedLectureId.value = id
            navigateTo(AppScreen.PROCESSING)
            
            // Start the extraction, chunking, and transcription simulation pipeline
            triggerProcessingPipeline(id)
        }
    }

    // File Upload Simulation
    fun uploadAudioFile(fileName: String, durationMin: Int) {
        val durationSec = durationMin.toLong() * 60
        viewModelScope.launch {
            val id = repository.createLecture(
                title = fileName,
                durationSeconds = durationSec,
                language = selectedLanguage.value,
                modelSize = selectedModel.value,
                status = "PROCESSING"
            )
            _selectedLectureId.value = id
            navigateTo(AppScreen.PROCESSING)

            // Process immediately
            triggerProcessingPipeline(id)
        }
    }

    private fun triggerProcessingPipeline(id: Long) {
        processingJob = viewModelScope.launch {
            try {
                // Fetch the detail
                val lecture = repository.getLectureById(id)
                _currentLecture.value = lecture

                // Run pipeline using repository
                repository.processLecturePipeline(id)

                // Select the processed completed lecture
                selectLecture(id)
                
                // Auto route to Transcript Screen on completion
                navigateTo(AppScreen.TRANSCRIPT)
            } catch (e: Exception) {
                Log.e(TAG, "Pipeline failed", e)
                navigateTo(AppScreen.HOME)
            }
        }
    }

    // Flashcard star toggle
    fun toggleFlashcardStarred(flashcard: FlashcardEntity) {
        viewModelScope.launch {
            repository.updateFlashcard(flashcard.copy(isStarred = !flashcard.isStarred))
        }
    }

    fun toggleFlashcardReviewed(flashcard: FlashcardEntity) {
        viewModelScope.launch {
            repository.updateFlashcard(flashcard.copy(isReviewed = !flashcard.isReviewed))
        }
    }

    // Quiz Game Machinery
    fun startQuiz() {
        _currentQuestionIndex.value = 0
        _selectedAnswerIndex.value = null
        _quizCorrectCount.value = 0
        _isQuizCompleted.value = false
    }

    fun selectQuizAnswer(option: String) {
        if (_selectedAnswerIndex.value != null) return // Already answered
        
        _selectedAnswerIndex.value = option
        val questions = _currentQuizQuestions.value
        val currentIndex = _currentQuestionIndex.value
        
        if (currentIndex < questions.size) {
            val correct = questions[currentIndex].correctAnswer.trim()
            if (option.trim().lowercase() == correct.lowercase()) {
                _quizCorrectCount.value += 1
            }
        }
    }

    fun nextQuizQuestion() {
        val questions = _currentQuizQuestions.value
        val nextIndex = _currentQuestionIndex.value + 1
        
        if (nextIndex < questions.size) {
            _currentQuestionIndex.value = nextIndex
            _selectedAnswerIndex.value = null
        } else {
            _isQuizCompleted.value = true
        }
    }

    // Check Gemini key active status
    fun hasGeminiKey(): Boolean {
        return GeminiClient.isApiKeyAvailable()
    }
}
