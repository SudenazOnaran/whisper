package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.LectureViewModel
import org.json.JSONArray
import org.json.JSONObject

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(viewModel: LectureViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DarkBg, Color(0xFF1B1525))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val scale by infiniteTransition.animateFloat(
            initialValue = 0.9f,
            targetValue = 1.1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_scale"
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .scale(scale)
                    .background(SlatePrimary, CircleShape)
                    .border(2.dp, SlateAccent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("🎓", fontSize = 48.sp)
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "AI Lecture Notes",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = AccentGold
                ),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Your Lectures, Decoded in Seconds",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = Color.LightGray.copy(alpha = 0.8f),
                    fontFamily = FontFamily.SansSerif
                )
            )
            Spacer(modifier = Modifier.height(48.dp))
            CircularProgressIndicator(
                color = SlateAccent,
                modifier = Modifier.size(32.dp),
                strokeWidth = 3.dp
            )
        }
    }
}

// ==========================================
// 3. HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: LectureViewModel) {
    val email by viewModel.currentUserEmail.collectAsState()
    val lectures by viewModel.allLectures.collectAsState()

    // Calculate aggregated statistics
    val completedLectures = lectures.filter { it.status == "COMPLETED" }
    val totalQuizzes = completedLectures.sumOf { it.quizCount }
    val totalFlashcards = completedLectures.sumOf { it.flashcardCount }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkBg)
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "WORKSPACE",
                            color = SlateSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 1.sp
                        )
                        Text(
                            "AI Lecture Notes",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 20.sp
                        )
                    }
                    val initials = if (email.isNotEmpty() && email.contains("@")) {
                        email.substringBefore("@").take(2).uppercase()
                    } else if (email.isNotEmpty()) {
                        email.take(2).uppercase()
                    } else {
                        "ST"
                    }
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SlateSecondary)
                            .clickable { viewModel.navigateTo(AppScreen.SETTINGS) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            color = SlatePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(AppScreen.RECORD_LECTURE) },
                containerColor = SlateAccent,
                contentColor = SlatePrimary
            ) {
                Text("🎙️", fontSize = 24.sp)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Stats Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📚", fontSize = 24.sp)
                        Text("Lectures", fontSize = 12.sp, color = Color.Gray)
                        Text(lectures.size.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🧪", fontSize = 24.sp)
                        Text("Questions", fontSize = 12.sp, color = Color.Gray)
                        Text(totalQuizzes.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚡", fontSize = 24.sp)
                        Text("Flashcards", fontSize = 12.sp, color = Color.Gray)
                        Text(totalFlashcards.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    }
                }
            }

            // Quick navigation panel matching Design HTML exactly
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(130.dp)
                        .clickable { viewModel.navigateTo(AppScreen.UPLOAD_LECTURE) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.Start
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF49454F), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📤", fontSize = 18.sp)
                        }
                        Column {
                            Text("Upload File", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = Color.White)
                            Text("MP3, WAV, MP4", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(130.dp)
                        .clickable { viewModel.navigateTo(AppScreen.HISTORY) },
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Color(0xFF49454F))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.Start
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF49454F), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📜", fontSize = 18.sp)
                        }
                        Column {
                            Text("History Logs", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = Color.White)
                            Text("Explore notes & quiz", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }

            // Recent Lectures Section Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Lectures",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                TextButton(onClick = { viewModel.navigateTo(AppScreen.HISTORY) }) {
                    Text("See All", color = SlateSecondary)
                }
            }

            if (lectures.isEmpty()) {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎤", fontSize = 48.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No lectures yet decapsulated.", color = Color.Gray)
                        Text("Tap the floating mic below to record!", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(lectures.take(4)) { item ->
                        LectureRowItem(item) {
                            viewModel.selectLecture(item.id)
                            if (item.status == "COMPLETED") {
                                viewModel.navigateTo(AppScreen.TRANSCRIPT)
                            } else if (item.status == "PROCESSING") {
                                viewModel.navigateTo(AppScreen.PROCESSING)
                            } else {
                                viewModel.navigateTo(AppScreen.HOME)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Reusable rows for lectures
@Composable
fun LectureRowItem(item: LectureEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color(0xFF49454F))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Elegant vertical status color strip matching border-l-4 in Design HTML
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(
                        when (item.status) {
                            "COMPLETED" -> SlateSecondary
                            "PROCESSING" -> Color(0xFFFFA726)
                            "FAILED" -> Color(0xFFEF4444)
                            else -> Color.DarkGray
                        }
                    )
            )

            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Custom language pills matching Design HTML tag colors
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (item.language.lowercase() == "tr") Color(0x33FFB300) else SlatePrimary,
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (item.language.lowercase() == "tr") "TR" else "EN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (item.language.lowercase() == "tr") Color(0xFFFFB300) else SlateSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.padding(end = 8.dp)) {
                        Text(
                            item.title,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("⏱️ ${item.audioDuration}", fontSize = 11.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🤖 Whisper ${item.modelSize.replaceFirstChar { it.uppercase() }}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                // Status chip badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when (item.status) {
                                "COMPLETED" -> Color(0xFF10B981).copy(alpha = 0.2f)
                                "PROCESSING" -> Color(0xFFFFA726).copy(alpha = 0.2f)
                                "FAILED" -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                else -> Color.DarkGray
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = item.status,
                        color = when (item.status) {
                            "COMPLETED" -> Color(0xFF10B981)
                            "PROCESSING" -> Color(0xFFFFA726)
                            "FAILED" -> Color(0xFFEF4444)
                            else -> Color.LightGray
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ==========================================
// 4. UPLOAD LECTURE SCREEN
// ==========================================
@Composable
fun UploadLectureScreen(viewModel: LectureViewModel) {
    var title by remember { mutableStateOf("Quantum Physics Intro") }
    var durationMin by remember { mutableStateOf("15") }
    val language by viewModel.selectedLanguage.collectAsState()
    val modelSize by viewModel.selectedModel.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Text("⬅️", fontSize = 20.sp)
                }
                Text("Upload Lecture", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            Text(
                "Upload Academic Lectures",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                "AI Lecture Notes supports up to 4-hour recordings. We chunk and process them securely.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Lecture Title / Subject") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = durationMin,
                        onValueChange = { durationMin = it },
                        label = { Text("Length (Minutes)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Text("Speech Model Parameters", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Model Selector
                    Text("Faster-Whisper Model Size:", color = Color.Gray, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.selectedModel.value = "small" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (modelSize == "small") SlateSecondary else Color.DarkGray
                            )
                        ) {
                            Text("Small (Fastest)")
                        }
                        Button(
                            onClick = { viewModel.selectedModel.value = "medium" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (modelSize == "medium") SlateSecondary else Color.DarkGray
                            )
                        ) {
                            Text("Medium (Accurate)")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Language Selector
                    Text("Lecture Primary Language:", color = Color.Gray, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("auto" to "🤖 Auto", "en" to "🇺🇸 EN", "tr" to "🇹🇷 TR").forEach { (code, label) ->
                            Button(
                                onClick = { viewModel.selectedLanguage.value = code },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (language == code) SlateSecondary else Color.DarkGray
                                )
                            ) {
                                Text(label, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val finalDuration = durationMin.toIntOrNull() ?: 15
                    viewModel.uploadAudioFile(title, finalDuration)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SlateAccent,
                    contentColor = SlatePrimary
                ),
                shape = RoundedCornerShape(26.dp)
            ) {
                Text("⚡ Launch Decapsulation Pipeline", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ==========================================
// 5. RECORD LECTURE SCREEN
// ==========================================
@Composable
fun RecordLectureScreen(viewModel: LectureViewModel) {
    var title by remember { mutableStateOf("") }
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingDurationSeconds by viewModel.recordingDurationSeconds.collectAsState()
    val waveAmplitudes by viewModel.recorderAmplitude.collectAsState()
    val language by viewModel.selectedLanguage.collectAsState()
    val modelSize by viewModel.selectedModel.collectAsState()

    val formattedTime = String.format(
        "%02d:%02d",
        recordingDurationSeconds / 60,
        recordingDurationSeconds % 60
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Text("⬅️", fontSize = 20.sp)
                }
                Text("Studio Live Recorder", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Simulated Voice Capture",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Streams voice segments straight to the custom chunking pipeline.",
                fontSize = 11.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Give this recording a name...") },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isRecording,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Pulse Timer Screen
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .background(DarkSurface, RoundedCornerShape(75.dp))
                    .border(3.dp, if (isRecording) CoralRed else Color.Gray, RoundedCornerShape(75.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isRecording) "🔴 REC" else "IDLE",
                        color = if (isRecording) CoralRed else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = formattedTime,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // Sound Wave Visualizer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(DarkSurface.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                if (waveAmplitudes.isEmpty()) {
                    Text("Waveform visualization starts with recording...", color = Color.DarkGray, fontSize = 11.sp)
                } else {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        waveAmplitudes.forEach { peak ->
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height((peak * 45).dp)
                                    .background(SlateSecondary, RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Fast config summary
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Default Language: ${language.uppercase()}", color = Color.LightGray, fontSize = 12.sp)
                Text("Whisper Model: ${modelSize.uppercase()}", color = Color.LightGray, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.weight(1f))

            if (!isRecording) {
                Button(
                    onClick = { viewModel.startRecording(title) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SlateAccent,
                        contentColor = SlatePrimary
                    ),
                    shape = RoundedCornerShape(27.dp)
                ) {
                    Text("🎙️ Start Recording Lecture", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            } else {
                Button(
                    onClick = { viewModel.stopRecordingAndProcess(title) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralRed),
                    shape = RoundedCornerShape(27.dp)
                ) {
                    Text("⏹️ Finish & Decapsulate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// ==========================================
// 6. PROCESSING SCREEN
// ==========================================
@Composable
fun ProcessingScreen(viewModel: LectureViewModel) {
    val currentLecture by viewModel.currentLecture.collectAsState()

    // Simulate animated ticks
    var stepIndex by remember { mutableStateOf(0) }

    LaunchedEffect(key1 = true) {
        stepIndex = 0
        delay(2000)
        stepIndex = 1
        delay(2500)
        stepIndex = 2
        delay(3000)
        stepIndex = 3
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    modifier = Modifier.size(100.dp),
                    color = SlateAccent,
                    strokeWidth = 6.dp
                )
                Text("🤖", fontSize = 42.sp)
            }

            Spacer(modifier = Modifier.height(30.dp))
            
            Text(
                text = "Processing: ${currentLecture?.title ?: "Academic Topic"}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                "Chunking audio to optimize computer RAM & calling Faster-Whisper",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray,
                modifier = Modifier.padding(top = 4.dp, bottom = 32.dp),
                textAlign = TextAlign.Center
            )

            // Dynamic Step Checklist
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ProcessingPipelineStep(label = "1. Extraction & Chunking (RAM Save)", done = stepIndex >= 1, active = stepIndex == 0)
                ProcessingPipelineStep(label = "2. Faster-Whisper Decoding (Small/Medium)", done = stepIndex >= 2, active = stepIndex == 1)
                ProcessingPipelineStep(label = "3. Language Detection & Segments Merge", done = stepIndex >= 3, active = stepIndex == 2)
                ProcessingPipelineStep(label = "4. Gemini JSON Structuring & Flashcards", done = stepIndex >= 4, active = stepIndex == 3)
            }
        }
    }
}

@Composable
fun ProcessingPipelineStep(label: String, done: Boolean, active: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(
                    if (done) EmeraldGreen else if (active) SlateAccent else Color.DarkGray,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (done) {
                Text("✓", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            } else if (active) {
                CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 1.5.dp, color = Color.Black)
            } else {
                Box(modifier = Modifier.size(6.dp).background(Color.White, CircleShape))
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            color = if (done) Color.LightGray else if (active) Color.White else Color.Gray,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            fontSize = 14.sp
        )
    }
}

// ==========================================
// SHARED NAVIGATION BAR (TRANSCRIPT, SUMMARY, FLASHCARDS, QUIZ)
// ==========================================
@Composable
fun DecodedTabBar(activeTab: AppScreen, onTabSelected: (AppScreen) -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            DecodedTabButton(label = "📝 Text", active = activeTab == AppScreen.TRANSCRIPT) {
                onTabSelected(AppScreen.TRANSCRIPT)
            }
            DecodedTabButton(label = "📊 Notes", active = activeTab == AppScreen.SUMMARY) {
                onTabSelected(AppScreen.SUMMARY)
            }
            DecodedTabButton(label = "⚡ Cards", active = activeTab == AppScreen.FLASHCARDS) {
                onTabSelected(AppScreen.FLASHCARDS)
            }
            DecodedTabButton(label = "🧠 Quiz", active = activeTab == AppScreen.QUIZ) {
                onTabSelected(AppScreen.QUIZ)
            }
        }
    }
}

@Composable
fun DecodedTabButton(label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            color = if (active) SlateAccent else Color.Gray,
            fontSize = 15.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        if (active) {
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(3.dp)
                    .background(SlateAccent, RoundedCornerShape(1.5.dp))
            )
        } else {
            Spacer(modifier = Modifier.height(3.dp))
        }
    }
}

// ==========================================
// 7. TRANSCRIPT SCREEN
// ==========================================
@Composable
fun TranscriptScreen(viewModel: LectureViewModel) {
    val currentLecture by viewModel.currentLecture.collectAsState()
    val currentTranscript by viewModel.currentTranscript.collectAsState()

    var interactiveMode by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                            Text("🏠", fontSize = 20.sp)
                        }
                        Text(
                            currentLecture?.title ?: "Transcript",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 200.dp)
                        )
                    }
                    Button(
                        onClick = { interactiveMode = !interactiveMode },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateSecondary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (interactiveMode) "📄 Raw Text" else "⏱️ Timeline", fontSize = 11.sp)
                    }
                }
                DecodedTabBar(AppScreen.TRANSCRIPT) { screen ->
                    viewModel.navigateTo(screen)
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (currentTranscript == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No transcript available.", color = Color.Gray)
                }
            } else {
                if (!interactiveMode) {
                    // Raw Continuous Text view
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        LazyColumn(modifier = Modifier.padding(16.dp)) {
                            item {
                                Text(
                                    currentTranscript!!.fullText,
                                    fontSize = 15.sp,
                                    lineHeight = 24.sp,
                                    color = Color.LightGray
                                )
                            }
                        }
                    }
                } else {
                    // Segment timelines
                    val segments = remember(currentTranscript) {
                        try {
                            val array = JSONArray(currentTranscript!!.segmentsJson)
                            val list = mutableListOf<Pair<String, String>>()
                            for (i in 0 until array.length()) {
                                val item = array.getJSONObject(i)
                                list.add(item.getString("time") to item.getString("text"))
                            }
                            list
                        } catch (e: Exception) {
                            emptyList<Pair<String, String>>()
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(segments) { index, (time, text) ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(12.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(SlatePrimary)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            time,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = SlateAccent
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text,
                                        fontSize = 14.sp,
                                        lineHeight = 20.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 8. SUMMARY SCREEN
// ==========================================
@Composable
fun SummaryScreen(viewModel: LectureViewModel) {
    val currentLecture by viewModel.currentLecture.collectAsState()
    val currentSummary by viewModel.currentSummary.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Overall, 1: Sections, 2: Key Concepts, 3: Glossary

    Scaffold(
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                        Text("🏠", fontSize = 20.sp)
                    }
                    Text(
                        currentLecture?.title ?: "Summary",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                DecodedTabBar(AppScreen.SUMMARY) { screen ->
                    viewModel.navigateTo(screen)
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(12.dp)
        ) {
            // Horizontal scroll subtabs
            ScrollableTabRow(
                selectedTabIndex = activeSubTab,
                containerColor = Color.Transparent,
                edgePadding = 0.dp
            ) {
                listOf("📝 Overall Summary", "📚 Chronology Sections", "⚡ Key Concepts", "📖 Definitions").forEachIndexed { index, title ->
                    Tab(
                        selected = activeSubTab == index,
                        onClick = { activeSubTab = index },
                        text = { Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                        selectedContentColor = SlateAccent,
                        unselectedContentColor = Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (currentSummary == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No notes extracted yet.", color = Color.Gray)
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (activeSubTab) {
                        0 -> {
                            // Overall Summary
                            LazyColumn(modifier = Modifier.padding(16.dp)) {
                                item {
                                    Text("Executive Academic Summary", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        currentSummary!!.summaryText,
                                        fontSize = 15.sp,
                                        lineHeight = 24.sp,
                                        color = Color.LightGray
                                    )
                                }
                            }
                        }
                        1 -> {
                            // Chronological Sections
                            val sections = remember(currentSummary) {
                                try {
                                    val array = JSONArray(currentSummary!!.sectionSummariesJson)
                                    val list = mutableListOf<Triple<String, String, String>>()
                                    for (i in 0 until array.length()) {
                                        val item = array.getJSONObject(i)
                                        list.add(
                                            Triple(
                                                item.getString("title"),
                                                item.getString("summary"),
                                                item.getString("time")
                                            )
                                        )
                                    }
                                    list
                                } catch (e: Exception) {
                                    emptyList()
                                }
                            }

                            LazyColumn(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(sections) { (title, sum, time) ->
                                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                                Text("⏱️ $time", color = SlateAccent, fontSize = 11.sp)
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(sum, fontSize = 13.sp, color = Color.LightGray)
                                        }
                                    }
                                }
                            }
                        }
                        2 -> {
                            // Key Concepts
                            val concepts = remember(currentSummary) {
                                try {
                                    val array = JSONArray(currentSummary!!.keyConceptsJson)
                                    val list = mutableListOf<Pair<String, String>>()
                                    for (i in 0 until array.length()) {
                                        val item = array.getJSONObject(i)
                                        list.add(item.getString("concept") to item.getString("description"))
                                    }
                                    list
                                } catch (e: Exception) {
                                    emptyList()
                                }
                            }

                            LazyColumn(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(concepts) { (name, desc) ->
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(modifier = Modifier.size(6.dp).background(SlateAccent, CircleShape))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(name, fontWeight = FontWeight.Bold, color = SlateAccent, fontSize = 14.sp)
                                        }
                                        Text(desc, fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.padding(start = 14.dp, top = 2.dp))
                                        Divider(color = Color.DarkGray, modifier = Modifier.padding(top = 10.dp))
                                    }
                                }
                            }
                        }
                        3 -> {
                            // Glossary Definitions
                            val definitions = remember(currentSummary) {
                                try {
                                    val array = JSONArray(currentSummary!!.definitionsJson)
                                    val list = mutableListOf<Pair<String, String>>()
                                    for (i in 0 until array.length()) {
                                        val item = array.getJSONObject(i)
                                        list.add(item.getString("term") to item.getString("definition"))
                                    }
                                    list
                                } catch (e: Exception) {
                                    emptyList()
                                }
                            }

                            LazyColumn(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(definitions) { (term, def) ->
                                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)) {
                                        Row(modifier = Modifier.padding(12.dp)) {
                                            Text(term, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.width(100.dp), fontSize = 13.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(def, fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 9. FLASHCARDS SCREEN
// ==========================================
@Composable
fun FlashcardsScreen(viewModel: LectureViewModel) {
    val currentLecture by viewModel.currentLecture.collectAsState()
    val flashcards by viewModel.currentFlashcards.collectAsState()

    var cardIndex by remember { mutableStateOf(0) }
    var isFlipped by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                        Text("🏠", fontSize = 20.sp)
                    }
                    Text(
                        currentLecture?.title ?: "Flashcards",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                DecodedTabBar(AppScreen.FLASHCARDS) { screen ->
                    viewModel.navigateTo(screen)
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (flashcards.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text("No flashcards compiled.", color = Color.Gray)
                }
            } else {
                val card = flashcards[cardIndex]

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    // Headline metadata
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Card ${cardIndex + 1} of ${flashcards.size}",
                            fontWeight = FontWeight.Bold,
                            color = SlateSecondary,
                            fontSize = 14.sp
                        )
                        Row {
                            IconButton(onClick = { viewModel.toggleFlashcardStarred(card) }) {
                                Text(if (card.isStarred) "⭐️" else "☆", fontSize = 20.sp)
                            }
                            IconButton(onClick = { viewModel.toggleFlashcardReviewed(card) }) {
                                Text(if (card.isReviewed) "✅ Got it!" else "⭕ Check", fontSize = 16.sp)
                            }
                        }
                    }

                    // Rotating animated Box card representation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(DarkSurface)
                            .border(2.dp, if (isFlipped) SlateAccent else SlateSecondary, RoundedCornerShape(20.dp))
                            .clickable { isFlipped = !isFlipped }
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (isFlipped) "💡 ANSWER" else "❓ QUESTION",
                                color = if (isFlipped) SlateAccent else SlateSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(
                                text = if (isFlipped) card.answer else card.question,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                lineHeight = 28.sp
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                "(Tap Card to Flip)",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Next / Prev Deck Controls
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 40.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Button(
                            onClick = {
                                if (cardIndex > 0) {
                                    cardIndex -= 1
                                    isFlipped = false
                                }
                            },
                            enabled = cardIndex > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SlateSecondary,
                                contentColor = SlatePrimary
                            )
                        ) {
                            Text("◀ Prev", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                if (cardIndex < flashcards.size - 1) {
                                    cardIndex += 1
                                    isFlipped = false
                                }
                            },
                            enabled = cardIndex < flashcards.size - 1,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SlateSecondary,
                                contentColor = SlatePrimary
                            )
                        ) {
                            Text("Next ▶", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 10. QUIZ SCREEN
// ==========================================
@Composable
fun QuizScreen(viewModel: LectureViewModel) {
    val currentLecture by viewModel.currentLecture.collectAsState()
    val quizQuestions by viewModel.currentQuizQuestions.collectAsState()

    val currentQuestionIndex by viewModel.currentQuestionIndex.collectAsState()
    val selectedAnswerIndex by viewModel.selectedAnswerIndex.collectAsState()
    val correctCount by viewModel.quizCorrectCount.collectAsState()
    val isQuizCompleted by viewModel.isQuizCompleted.collectAsState()

    Scaffold(
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                        Text("🏠", fontSize = 20.sp)
                    }
                    Text(
                        currentLecture?.title ?: "Quiz",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                DecodedTabBar(AppScreen.QUIZ) { screen ->
                    viewModel.navigateTo(screen)
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (quizQuestions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No quiz compiled.", color = Color.Gray)
                }
            } else if (isQuizCompleted) {
                // Completed State Screen summary
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🏁 Quiz Complete!", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = SlateAccent)
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            val scorePercentage = ((correctCount.toFloat() / quizQuestions.size.toFloat()) * 100).toInt()
                            
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
                                CircularProgressIndicator(
                                    progress = { correctCount.toFloat() / quizQuestions.size.toFloat() },
                                    modifier = Modifier.fillMaxSize(),
                                    color = EmeraldGreen,
                                    strokeWidth = 8.dp
                                )
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("$scorePercentage%", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Text("Accuracy", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "You answered $correctCount out of ${quizQuestions.size} correctly.",
                                color = Color.LightGray,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            
                            Button(
                                onClick = { viewModel.startQuiz() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SlateSecondary,
                                    contentColor = SlatePrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Try Again", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                val q = quizQuestions[currentQuestionIndex]

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Header progress
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Question ${currentQuestionIndex + 1} of ${quizQuestions.size}", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Score: $correctCount", color = EmeraldGreen, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        LinearProgressIndicator(
                            progress = { (currentQuestionIndex + 1).toFloat() / quizQuestions.size.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = SlateSecondary,
                            trackColor = Color.DarkGray
                        )
                    }

                    // Question Card
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            q.questionText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Answer Options (A, B, C, D)
                    val options = listOf(
                        "A" to q.optionA,
                        "B" to q.optionB,
                        "C" to q.optionC,
                        "D" to q.optionD
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        options.forEach { (option, text) ->
                            val isCorrect = option.lowercase() == q.correctAnswer.lowercase()
                            val isSelected = option == selectedAnswerIndex
                            val optionBg = when {
                                selectedAnswerIndex == null -> DarkSurface
                                isSelected && isCorrect -> EmeraldGreen.copy(alpha = 0.3f)
                                isSelected && !isCorrect -> CoralRed.copy(alpha = 0.3f)
                                isCorrect -> EmeraldGreen.copy(alpha = 0.2f)
                                else -> DarkSurface.copy(alpha = 0.5f)
                            }
                            val optionBorderColor = when {
                                isSelected && isCorrect -> EmeraldGreen
                                isSelected && !isCorrect -> CoralRed
                                isCorrect -> EmeraldGreen
                                else -> Color.DarkGray
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, optionBorderColor, RoundedCornerShape(12.dp))
                                    .clickable { viewModel.selectQuizAnswer(option) },
                                colors = CardDefaults.cardColors(containerColor = optionBg),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(14.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .border(1.dp, Color.Gray, CircleShape)
                                            .background(
                                                if (isSelected) SlateAccent else Color.Transparent,
                                                CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(option, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text, color = Color.White)
                                }
                            }
                        }
                    }

                    // Explanation & Next Control Box
                    Spacer(modifier = Modifier.weight(1f))
                    if (selectedAnswerIndex != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 100.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp)) {
                                Text("💡", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                LazyColumn(modifier = Modifier.weight(1f)) {
                                    item {
                                        Text(q.explanation, fontSize = 11.sp, color = Color.LightGray)
                                    }
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        Button(
                            onClick = { viewModel.nextQuizQuestion() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SlateAccent,
                                contentColor = SlatePrimary
                            ),
                            shape = RoundedCornerShape(22.dp)
                        ) {
                            Text("Next Question ->", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Empty spacer to occupy same constraint bound
                        Spacer(modifier = Modifier.height(54.dp))
                    }
                }
            }
        }
    }
}

// ==========================================
// 11. HISTORY SCREEN
// ==========================================
@Composable
fun HistoryScreen(viewModel: LectureViewModel) {
    val lectures by viewModel.allLectures.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredLectures = lectures.filter {
        it.title.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                    Text("⬅️", fontSize = 20.sp)
                }
                Text("Search Lectures", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search title, subject, or class...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            if (filteredLectures.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text("No matched logs in archives.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredLectures) { item ->
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.weight(1f)) {
                                LectureRowItem(item) {
                                    viewModel.selectLecture(item.id)
                                    viewModel.navigateTo(AppScreen.TRANSCRIPT)
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(onClick = { viewModel.deleteLecture(item.id) }) {
                                Text("🗑️", fontSize = 16.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 12. SETTINGS SCREEN
// ==========================================
@Composable
fun SettingsScreen(viewModel: LectureViewModel) {
    val email by viewModel.currentUserEmail.collectAsState()
    val modelSize by viewModel.selectedModel.collectAsState()
    val language by viewModel.selectedLanguage.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.clearBackStackAndNavigate(AppScreen.HOME) }) {
                    Text("⬅️", fontSize = 20.sp)
                }
                Text("App Preferences", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 18.sp)
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            // User Session Details card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("👤", fontSize = 32.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Student Workspace Profile", fontWeight = FontWeight.Bold, color = Color.White)
                        Text("student@university.edu", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }

            Text("STT Engine Parameters", color = SlateSecondary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))

            // Whisper Selector Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Faster-Whisper Model Select", fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Smaller builds speed up decryption, larger models boost vocabularies.", fontSize = 11.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))
                    Row {
                        Button(
                            onClick = { viewModel.selectedModel.value = "small" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (modelSize == "small") SlateSecondary else Color.DarkGray,
                                contentColor = if (modelSize == "small") SlatePrimary else Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Small", fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.selectedModel.value = "medium" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (modelSize == "medium") SlateSecondary else Color.DarkGray,
                                contentColor = if (modelSize == "medium") SlatePrimary else Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Medium", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // AI Status key Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("AI Coprocessor Credentials", fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            text = if (viewModel.hasGeminiKey()) "Gemini-3.5-Flash Active (Server Key Loaded)" else "Using High-Fidelity Local Simulator Engine",
                            fontSize = 11.sp,
                            color = if (viewModel.hasGeminiKey()) EmeraldGreen else SlateSecondary
                        )
                    }
                    Text(if (viewModel.hasGeminiKey()) "🟢" else "🟡", fontSize = 20.sp)
                }
            }
        }
    }
}
