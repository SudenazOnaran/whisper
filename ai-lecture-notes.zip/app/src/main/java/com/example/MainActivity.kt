package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.LectureViewModel
import com.example.ui.screens.*

class MainActivity : ComponentActivity() {
    private val viewModel: LectureViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val currentScreen by viewModel.currentScreen.collectAsState()

                // Intercept back button triggers to safely pop backstack
                BackHandler(enabled = currentScreen != AppScreen.SPLASH && currentScreen != AppScreen.HOME) {
                    viewModel.navigateBack()
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                        },
                        label = "screen_transitions"
                    ) { screen ->
                        when (screen) {
                            AppScreen.SPLASH -> SplashScreen(viewModel)
                            AppScreen.HOME -> HomeScreen(viewModel)
                            AppScreen.UPLOAD_LECTURE -> UploadLectureScreen(viewModel)
                            AppScreen.RECORD_LECTURE -> RecordLectureScreen(viewModel)
                            AppScreen.PROCESSING -> ProcessingScreen(viewModel)
                            AppScreen.TRANSCRIPT -> TranscriptScreen(viewModel)
                            AppScreen.SUMMARY -> SummaryScreen(viewModel)
                            AppScreen.FLASHCARDS -> FlashcardsScreen(viewModel)
                            AppScreen.QUIZ -> QuizScreen(viewModel)
                            AppScreen.HISTORY -> HistoryScreen(viewModel)
                            AppScreen.SETTINGS -> SettingsScreen(viewModel)
                        }
                    }
                }
            }
        }
    }
}
