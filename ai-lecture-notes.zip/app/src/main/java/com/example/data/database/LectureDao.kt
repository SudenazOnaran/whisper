package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LectureDao {
    @Query("SELECT * FROM lectures ORDER BY dateCreated DESC")
    fun getAllLectures(): Flow<List<LectureEntity>>

    @Query("SELECT * FROM lectures WHERE id = :id")
    suspend fun getLectureById(id: Long): LectureEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLecture(lecture: LectureEntity): Long

    @Update
    suspend fun updateLecture(lecture: LectureEntity)

    @Query("DELETE FROM lectures WHERE id = :id")
    suspend fun deleteLecture(id: Long)

    @Query("UPDATE lectures SET status = :status WHERE id = :id")
    suspend fun updateLectureStatus(id: Long, status: String)

    // Transcript queries
    @Query("SELECT * FROM transcripts WHERE lectureId = :lectureId")
    suspend fun getTranscriptForLecture(lectureId: Long): TranscriptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranscript(transcript: TranscriptEntity)

    // Summary queries
    @Query("SELECT * FROM summaries WHERE lectureId = :lectureId")
    suspend fun getSummaryForLecture(lectureId: Long): SummaryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSummary(summary: SummaryEntity)

    // Flashcard queries
    @Query("SELECT * FROM flashcards WHERE lectureId = :lectureId")
    fun getFlashcardsForLectureFlow(lectureId: Long): Flow<List<FlashcardEntity>>

    @Query("SELECT * FROM flashcards WHERE lectureId = :lectureId")
    suspend fun getFlashcardsForLecture(lectureId: Long): List<FlashcardEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFlashcards(flashcards: List<FlashcardEntity>)

    @Update
    suspend fun updateFlashcard(flashcard: FlashcardEntity)

    // Quiz queries
    @Query("SELECT * FROM quiz_questions WHERE lectureId = :lectureId")
    suspend fun getQuizForLecture(lectureId: Long): List<QuizQuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizQuestions(questions: List<QuizQuestionEntity>)
}
