package com.example.data.repository

import com.example.data.api.GeminiClient
import com.example.data.database.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject
import org.json.JSONArray
import android.util.Log

class LectureRepository(private val lectureDao: LectureDao) {

    private val TAG = "LectureRepository"

    val allLectures: Flow<List<LectureEntity>> = lectureDao.getAllLectures()

    suspend fun getLectureById(id: Long): LectureEntity? = lectureDao.getLectureById(id)

    suspend fun deleteLecture(id: Long) = lectureDao.deleteLecture(id)

    fun getFlashcardsForLectureFlow(lectureId: Long): Flow<List<FlashcardEntity>> = 
        lectureDao.getFlashcardsForLectureFlow(lectureId)

    suspend fun updateFlashcard(flashcard: FlashcardEntity) = lectureDao.updateFlashcard(flashcard)

    suspend fun getTranscriptForLecture(lectureId: Long): TranscriptEntity? =
        lectureDao.getTranscriptForLecture(lectureId)

    suspend fun getSummaryForLecture(lectureId: Long): SummaryEntity? =
        lectureDao.getSummaryForLecture(lectureId)

    suspend fun getQuizForLecture(lectureId: Long): List<QuizQuestionEntity> =
        lectureDao.getQuizForLecture(lectureId)

    /**
     * Inserts an initial lecture placeholder. Returns the generated ID.
     */
    suspend fun createLecture(
        title: String,
        durationSeconds: Long,
        language: String,
        modelSize: String,
        status: String
    ): Long {
        val min = (durationSeconds / 60).toInt()
        val sec = (durationSeconds % 60).toInt()
        val durationString = String.format("%02d:%02d", min, sec)

        val lecture = LectureEntity(
            title = title,
            durationSeconds = durationSeconds,
            language = language,
            modelSize = modelSize,
            status = status,
            audioDuration = durationString
        )
        return lectureDao.insertLecture(lecture)
    }

    /**
     * Triggers transcription, summary, flashcards & quiz generation pipeline.
     */
    suspend fun processLecturePipeline(lectureId: Long) {
        val lecture = lectureDao.getLectureById(lectureId) ?: return
        
        try {
            // 1. Update status to PROCESSING
            lectureDao.updateLectureStatus(lectureId, "PROCESSING")

            // 2. Fetch processed JSON result from API/Simulator
            val durationMin = (lecture.durationSeconds / 60).toInt().coerceAtLeast(1)
            val jsonResult = GeminiClient.processLecture(
                title = lecture.title,
                durationMin = durationMin,
                language = lecture.language
            )

            // 3. Parse and Insert structured data
            parseAndSaveResults(lectureId, jsonResult)

            // 4. Update status to COMPLETED with counts
            val updatedLecture = lectureDao.getLectureById(lectureId)
            if (updatedLecture != null) {
                val flashcards = lectureDao.getFlashcardsForLecture(lectureId)
                val quiz = lectureDao.getQuizForLecture(lectureId)
                val summary = lectureDao.getSummaryForLecture(lectureId)
                
                // Parse sections count from summary json
                val sectionsJson = summary?.sectionSummariesJson ?: "[]"
                val sectionsCount = try { JSONArray(sectionsJson).length() } catch (e: Exception) { 0 }

                lectureDao.updateLecture(
                    updatedLecture.copy(
                        status = "COMPLETED",
                        flashcardCount = flashcards.size,
                        quizCount = quiz.size,
                        sectionCount = sectionsCount
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in processLecturePipeline for lecture ID $lectureId", e)
            lectureDao.updateLectureStatus(lectureId, "FAILED")
        }
    }

    private suspend fun parseAndSaveResults(lectureId: Long, jsonString: String) {
        val root = JSONObject(jsonString)

        // A. Parse Transcript
        val transcriptObj = root.getJSONObject("transcript")
        val fullText = transcriptObj.getString("fullText")
        val segmentsArray = transcriptObj.getJSONArray("segments")
        
        val transcriptEntity = TranscriptEntity(
            lectureId = lectureId,
            fullText = fullText,
            segmentsJson = segmentsArray.toString()
        )
        lectureDao.insertTranscript(transcriptEntity)

        // B. Parse Summary
        val summaryObj = root.getJSONObject("summary")
        val overall = summaryObj.getString("overall")
        val sectionsArray = summaryObj.getJSONArray("sections")
        val conceptsArray = summaryObj.getJSONArray("concepts")
        val definitionsArray = summaryObj.getJSONArray("definitions")

        val summaryEntity = SummaryEntity(
            lectureId = lectureId,
            summaryText = overall,
            keyConceptsJson = conceptsArray.toString(),
            definitionsJson = definitionsArray.toString(),
            sectionSummariesJson = sectionsArray.toString()
        )
        lectureDao.insertSummary(summaryEntity)

        // C. Parse Flashcards
        val flashcardsArray = root.getJSONArray("flashcards")
        val flashcardEntities = mutableListOf<FlashcardEntity>()
        for (i in 0 until flashcardsArray.length()) {
            val item = flashcardsArray.getJSONObject(i)
            flashcardEntities.add(
                FlashcardEntity(
                    lectureId = lectureId,
                    question = item.getString("question"),
                    answer = item.getString("answer")
                )
            )
        }
        lectureDao.insertFlashcards(flashcardEntities)

        // D. Parse Quiz
        val quizArray = root.getJSONArray("quiz")
        val quizEntities = mutableListOf<QuizQuestionEntity>()
        for (i in 0 until quizArray.length()) {
            val item = quizArray.getJSONObject(i)
            quizEntities.add(
                QuizQuestionEntity(
                    lectureId = lectureId,
                    questionText = item.getString("question"),
                    optionA = item.getString("optionA"),
                    optionB = item.getString("optionB"),
                    optionC = item.getString("optionC"),
                    optionD = item.getString("optionD"),
                    correctAnswer = item.getString("correctAnswer"),
                    explanation = item.getString("explanation")
                )
            )
        }
        lectureDao.insertQuizQuestions(quizEntities)
    }
}
