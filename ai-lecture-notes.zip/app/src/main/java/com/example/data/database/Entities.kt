package com.example.data.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "lectures")
data class LectureEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val durationSeconds: Long,
    val dateCreated: Long = System.currentTimeMillis(),
    val language: String, // "en" or "tr" or "auto"
    val modelSize: String, // "small" or "medium"
    val status: String, // "RECORDING", "PROCESSING", "COMPLETED", "FAILED"
    val audioDuration: String = "00:00",
    val sectionCount: Int = 0,
    val flashcardCount: Int = 0,
    val quizCount: Int = 0
)

@Entity(
    tableName = "transcripts",
    foreignKeys = [
        ForeignKey(
            entity = LectureEntity::class,
            parentColumns = ["id"],
            childColumns = ["lectureId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lectureId"])]
)
data class TranscriptEntity(
    @PrimaryKey val lectureId: Long,
    val fullText: String,
    val segmentsJson: String // Serialized transcript segments (timestamp + text)
)

@Entity(
    tableName = "summaries",
    foreignKeys = [
        ForeignKey(
            entity = LectureEntity::class,
            parentColumns = ["id"],
            childColumns = ["lectureId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lectureId"])]
)
data class SummaryEntity(
    @PrimaryKey val lectureId: Long,
    val summaryText: String,
    val keyConceptsJson: String, // Serialized list of keys & descriptions
    val definitionsJson: String, // Serialized list of words & definitions
    val sectionSummariesJson: String // Serialized section breakdowns
)

@Entity(
    tableName = "flashcards",
    foreignKeys = [
        ForeignKey(
            entity = LectureEntity::class,
            parentColumns = ["id"],
            childColumns = ["lectureId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lectureId"])]
)
data class FlashcardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lectureId: Long,
    val question: String,
    val answer: String,
    val isReviewed: Boolean = false,
    val isStarred: Boolean = false
)

@Entity(
    tableName = "quiz_questions",
    foreignKeys = [
        ForeignKey(
            entity = LectureEntity::class,
            parentColumns = ["id"],
            childColumns = ["lectureId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["lectureId"])]
)
data class QuizQuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lectureId: Long,
    val questionText: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswer: String, // "A", "B", "C", or "D"
    val explanation: String
)
